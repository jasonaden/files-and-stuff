'use strict';
(function() {
	//DevelopIntelligence Namespace
	window.DI = window.DI || {};
}());

DI.interaction = function() {

	var QUESTION = 'What is your favorite snack food?';
	var response = prompt(QUESTION,'hello');

	console.log('So you like to eat ' + response);
};

DI.interaction();