/** 
 * Give page interaction.
 **/
(function() {
  	'use strict';

  	//FastClick.attach(document.body);

  	//Form elements
  	var FORM_ID = 'donorForm';
  	var NAME_ID = 'giverName';
  	var STREET_ADDRESS_ID = 'streetAddress';
  	var ZIPCODE_ID = 'zipcode';
  	var PHONE_ID = 'phone';
  	var EMAIL_ID = 'email';
  	var CONTACT_CHOICE_ID = 'contactChoice';
  	var DATEPICKER_ID = 'datepicker';
  	var VALIDATION_ALERT_ID = 'validationAlert';
  	var LOCAL_STORAGE_POPULATE_KEY = 'giveForm';
  	var LOCAL_STORAGE_OFFLINE_KEY = 'giveOffline';
  	var OFFLINE_WARNING_ID = 'offlineWarning';
   	var ONLINE_SUCCESS_ID = 'onlineSuccess'; 
   	var OFFLINE_SUCCESS_ID = 'offlineSuccess';	

  	var online = true;

	var removeDate = function() {
		$('#datepicker').val('');
	};

	/**
	 *	Reset the warnings and alerts because of an invalid form.
	 **/
	var resetVisualFormValidation = function() {
		//Remove all errors
		$('label[for]').removeClass('error');
		//Hide validation alert
		$('#' + VALIDATION_ALERT_ID).hide();
	};

	/** 
	 *	Check form validation.
	 **/
	var isFormValid = function() {
		var isValid = true;

		resetVisualFormValidation();

		//Check Giver Street Address validation
		if (!document.getElementById(STREET_ADDRESS_ID ).validity.valid) {
			isValid = false;
			$('#' + STREET_ADDRESS_ID).prev().addClass('error');
		}

		//Check Giver Zipcode validation
		if (!document.getElementById(ZIPCODE_ID).validity.valid) {
			isValid = false;
			$('#' + ZIPCODE_ID).prev().addClass('error');					
		}

		//Check Giver Phone validation
		if (!document.getElementById(PHONE_ID).validity.valid) {
			isValid = false;
			$('#' + PHONE_ID).prev().addClass('error');		
		}

		//Check Giver Email validation
		if (!document.getElementById(EMAIL_ID).validity.valid) {
			isValid = false;
			$('#' + EMAIL_ID).prev().addClass('error');		
		}

		//Check Giver Contact Choice validation
		if (!document.getElementById(CONTACT_CHOICE_ID).validity.valid) {
			isValid = false;
			$('#' + CONTACT_CHOICE_ID).prev().addClass('error');		
		}	

		//Check Giver Datepicker validation
		if (!document.getElementById(DATEPICKER_ID).validity.valid) {
			isValid = false;
			$('#' + DATEPICKER_ID).prev().addClass('error');		
		}	

		//Check Giver Name validation
		if (!document.getElementById(NAME_ID).validity.valid) {
			isValid = false;
			$('#' + NAME_ID).prev().addClass('error');		
		}						

		return isValid;
	}

	/**
	 * Toggle online/offline status with offline showing.
	 **/
	var offlineSuccess = function() {
		$('#' + ONLINE_SUCCESS_ID).hide();
		$('#' + OFFLINE_SUCCESS_ID).show();
	};

	/**
	 * Toggle offline/online status with online showing.
	 **/
	var onlineSuccess = function() {
		$('#' + OFFLINE_SUCCESS_ID).hide();
		$('#' + ONLINE_SUCCESS_ID).show();
	};

	/**
	 * Check to see if we can validate the form.
	 **/
	var submissionHandler = function(event) {
		event.preventDefault();
		if(isFormValid()) {
			removeStoredFormData(LOCAL_STORAGE_POPULATE_KEY);

			//If we aren't online we want to store it to local storage
			if (!online) {
				storeFormData(LOCAL_STORAGE_OFFLINE_KEY);
				offlineSuccess();
			} else {
				removeStoredFormData(LOCAL_STORAGE_OFFLINE_KEY);
				onlineSuccess();
			}

			$('#' + FORM_ID)[0].reset()

		} else {
			//Show validation alert
			$('#' + VALIDATION_ALERT_ID).show();
			$('#' + OFFLINE_SUCCESS_ID).hide();
			$('#' + ONLINE_SUCCESS_ID).hide();
			document.getElementById(VALIDATION_ALERT_ID).focus();
		}
	};

	/**
	 * Event handler for storing offline form data.
	 **/
	var storeOfflineFormDataHandler = function() {
		storeFormData(LOCAL_STORAGE_OFFLINE_KEY);
	};

	/** 
	 * Event handler for storing form data.
	 **/
	var storeCurrentFormDataHandler = function() {
		storeFormData(LOCAL_STORAGE_POPULATE_KEY);
	};

	/**
	 * Store Form Data locally.
	 * @param key is the local storage key
	 **/
	var storeFormData = function(key) {
		var giver = {};

		giver.name = $('#' + NAME_ID).val();
		giver.phone = $('#' + PHONE_ID).val();
		giver.streetAddress = $('#' + STREET_ADDRESS_ID).val();
		giver.zipcode = $('#' + ZIPCODE_ID).val();
		giver.email = $('#' + EMAIL_ID).val();
		giver.contactChoice = $('#' + CONTACT_CHOICE_ID).val();
		giver.date = $('#' + DATEPICKER_ID).val();

		window.localStorage[key] = JSON.stringify(giver);

	};

	/**
	 * Retrieve Local storage data
	 **/
	var retrieveFormData = function(key) {
		var giverData = {};
		
		if (window.localStorage[key]) {
			giverData = JSON.parse(window.localStorage[key]);
		} else {
			giverData = undefined;
		}

		return giverData;

	};

	/**
	 * Removes Form Data from local storage.
	 * @param key is the local storage object key
	 **/
	var removeStoredFormData = function(key) {

		if (window.localStorage[key]) {
			window.localStorage.removeItem(key);
		}

	};

	/**
	 * Setup form listeners.
	 **/
	var inializeFormListeners = function() {
		//Handle form submission
		$('#donorForm').submit(submissionHandler);

		//Set up form local storage listeners
		$('label + input').on('blur', storeCurrentFormDataHandler);

		//Set up form local storage for select
		$('select').on('change', storeCurrentFormDataHandler);

		//Used if bringing in Hammer.js and Hammer.js jQuery plugin
		$('.removeIt').hammer().on('panleft', removeDate);

		//Full Hammer.js implementation without jQuery dependency
	  	/*
	  	var mc = new Hammer($('.removeIt')[0]);
		mc.on('panleft', removeDate);
		*/

	};

	/**
	 * Grab data from local storage if there is any and
	 *	populate the form.
	 **/
	var inializeFormData = function() {
		var giver = retrieveFormData(LOCAL_STORAGE_POPULATE_KEY);

		if (giver) {
			$('#' + NAME_ID).val(giver.name);
			$('#' + PHONE_ID).val(giver.phone);
			$('#' + STREET_ADDRESS_ID).val(giver.streetAddress);
			$('#' + ZIPCODE_ID).val(giver.zipcode);
			$('#' + EMAIL_ID).val(giver.email);
			$('#' + CONTACT_CHOICE_ID).val(giver.contactChoice);
			$('#' + DATEPICKER_ID).val(giver.date);
		}

	};

	/**
	 * Handle the application coming back online
	 **/
	var comingOnlineHandler = function() {
		online = true;
		$('#' + OFFLINE_WARNING_ID).hide();

		//Update the offline donor information
		if (retrieveFormData(LOCAL_STORAGE_OFFLINE_KEY)) {
			//If we find data to store to the backend ... do it
			//	perform an ajax call to store the data
			//Take data from retrieveFormData(LOCAL_STORAGE_OFFLINE_KEY)
			//	and send it to the backend

			//Remove data from local storage on successfull save
			removeStoredFormData(LOCAL_STORAGE_OFFLINE_KEY);
			
			//This would be wrapped in a promise after the storage took place
			//	Promises in next JavaScript class :)
			onlineSuccess();
		} else {
			//If there is no offline data to store to the backedn we don't
			//	show a message
			$('#' + OFFLINE_SUCCESS_ID).hide();
			$('#' + ONLINE_SUCCESS_ID).hide();
		}
	};

	/** 
	 * Initialize the listeners for offline interaction.
	 **/ 
	var inializeOfflineInteraction = function() {
		var offlineEl = $('#' + OFFLINE_WARNING_ID);

		//Check initial status
		if (window.navigator.onLine) {
			comingOnlineHandler();
		} else {
			online = false;
			offlineEl.show();
			$('#' + OFFLINE_SUCCESS_ID).hide();
			$('#' + ONLINE_SUCCESS_ID).hide();
		}

		//Hide offline warning
		$(window).on('online', comingOnlineHandler);

		//Show offline warning
		$(window).on('offline', function() {
			online = false;
			offlineEl.show();
		});

	};

	//Main function
	$(function() {

		$('#datepicker').datepicker({
	  		minDate: 1
	  	});

		resetVisualFormValidation();

		inializeFormListeners();

		inializeFormData();

		inializeOfflineInteraction();

	});

})();