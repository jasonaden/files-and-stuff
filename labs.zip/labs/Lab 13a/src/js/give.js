/** 
 * Give page interaction.
 **/
(function() {
  	'use strict';

  	//Form elements
  	var NAME_ID = 'giverName';
  	var STREET_ADDRESS_ID = 'streetAddress';
  	var ZIPCODE_ID = 'zipcode';
  	var PHONE_ID = 'phone';
  	var EMAIL_ID = 'email';
  	var CONTACT_CHOICE_ID = 'contactChoice';
  	var DATEPICKER_ID = 'datepicker';

  	//FastClick.attach(document.body);

	var removeDate = function() {
		$('#' + DATEPICKER_ID).val('');
	};
	
	//Full Hammer.js implementation without jQuery dependency
  	/*
  	var mc = new Hammer($('.removeIt')[0]);
	mc.on('panleft', removeDate);
	*/

	/** 
	 *  Set form validation Error
	 **/
	var setError = function(elementId) {
		$('#' + elementId).prev().addClass('error');
		document.getElementById(elementId).focus();
	};

	/** 
	 *	Check form validation.
	 **/
	var isFormValid = function() {
		var isValid = true;

		//Remove all errors
		$('label[for]').removeClass('error');

		//Check Giver Street Address validation
		if (!document.getElementById(STREET_ADDRESS_ID ).validity.valid) {
			isValid = false;
			setError(STREET_ADDRESS_ID);
		}

		//Check Giver Zipcode validation
		if (!document.getElementById(ZIPCODE_ID).validity.valid) {
			isValid = false;
			setError(ZIPCODE_ID);			
		}

		//Check Giver Phone validation
		if (!document.getElementById(PHONE_ID).validity.valid) {
			isValid = false;
			setError(PHONE_ID);
		}

		//Check Giver Email validation
		if (!document.getElementById(EMAIL_ID).validity.valid) {
			isValid = false;
			setError(EMAIL_ID);
		}

		//Check Giver Contact Choice validation
		if (!document.getElementById(CONTACT_CHOICE_ID).validity.valid) {
			isValid = false;
			setError(CONTACT_CHOICE_ID);
		}	

		//Check Giver Datepicker validation
		if (!document.getElementById(DATEPICKER_ID).validity.valid) {
			isValid = false;
			setError(DATEPICKER_ID);
		}	

		//Check Giver Name validation
		if (!document.getElementById(NAME_ID).validity.valid) {
			isValid = false;
			setError(NAME_ID);
		}						

		return isValid;
	}

	/**
	 * Check to see if we can validate the form.
	 **/
	var submissionHandler = function(event) {
		if(isFormValid()) {
			alert('yeah valid');
		} else {
			event.preventDefault();
			alert('please review the form');
		}
	};

	/**
	 * Add any custom validation messages we may want.
	 **/
	var addCustomValidationMessages = function() {
		var giverNameEl = $('#giverName');

		//Setting invalid message
		giverNameEl.on('invalid', function(event) {
			event.target.setCustomValidity('Please enter at least 2 letters');
		});

		//Allowing validation to pass when valid input
		giverNameEl.on('input', function(event) {
			event.target.setCustomValidity('');
		});
		
	};

	//Main method
	$(function() {

		Modernizr.load({
  			test: Modernizr.inputtypes.date,
  			nope: [
  				'js/libs/jquery-ui.js', 
  				'css/libs/jquery-ui.css',
  				'css/libs/jquery-ui.theme.css'
  			],
  			callback: {
  				'jquery-ui.js': function () {
      			//Only load the datepicker if our browser doesn't support it
				  	('#' + DATEPICKER_ID).datepicker({
				  		$minDate: 1
				  	});
				 }
			}
		});

		//Add a bit of custom validation
		addCustomValidationMessages();

		//Handle form submission
		$('#donorForm').submit(submissionHandler);

		//Used if bringing in Hammer.js and Hammer.js jQuery plugin
		$('.removeIt').hammer().on('panleft', removeDate);

	});
})();