/** 
 * Give page interaction.
 **/
(function() {
  	'use strict';

  	//FastClick.attach(document.body);

  	//Form elements
  	var NAME_ID = 'giverName';
  	var STREET_ADDRESS_ID = 'streetAddress';
  	var ZIPCODE_ID = 'zipcode';
  	var PHONE_ID = 'phone';
  	var EMAIL_ID = 'email';
  	var CONTACT_CHOICE_ID = 'contactChoice';
  	var DATEPICKER_ID = 'datepicker';
  	var VALIDATION_ALERT_ID = 'validationAlert';

	var removeDate = function() {
		$('#datepicker').val('');
		console.log('hello debugger');
	};

	/**
	 *	Reset the warnings and alerts because of an invalid form.
	 **/
	var resetVisualFormValidation = function() {
		//Remove all errors
		$('label[for]').removeClass('error');
		//Hide validation alert
		$('#' + VALIDATION_ALERT_ID).hide();
	};

	/** 
	 *	Check form validation.
	 **/
	var isFormValid = function() {
		var isValid = true;

		resetVisualFormValidation();

		//Check Giver Street Address validation
		if (!document.getElementById(STREET_ADDRESS_ID ).validity.valid) {
			isValid = false;
			$('#' + STREET_ADDRESS_ID).prev().addClass('error');
		}

		//Check Giver Zipcode validation
		if (!document.getElementById(ZIPCODE_ID).validity.valid) {
			isValid = false;
			$('#' + ZIPCODE_ID).prev().addClass('error');					
		}

		//Check Giver Phone validation
		if (!document.getElementById(PHONE_ID).validity.valid) {
			isValid = false;
			$('#' + PHONE_ID).prev().addClass('error');		
		}

		//Check Giver Email validation
		if (!document.getElementById(EMAIL_ID).validity.valid) {
			isValid = false;
			$('#' + EMAIL_ID).prev().addClass('error');		
		}

		//Check Giver Contact Choice validation
		if (!document.getElementById(CONTACT_CHOICE_ID).validity.valid) {
			isValid = false;
			$('#' + CONTACT_CHOICE_ID).prev().addClass('error');		
		}	

		//Check Giver Datepicker validation
		if (!document.getElementById(DATEPICKER_ID).validity.valid) {
			isValid = false;
			$('#' + DATEPICKER_ID).prev().addClass('error');		
		}	

		//Check Giver Name validation
		if (!document.getElementById(NAME_ID).validity.valid) {
			isValid = false;
			$('#' + NAME_ID).prev().addClass('error');		
		}						

		return isValid;
	}

	/**
	 * Check to see if we can validate the form.
	 **/
	var submissionHandler = function(event) {
		if(isFormValid()) {
			alert('yeah valid');
		} else {
			event.preventDefault();
			//Show validation alert
			$('#' + VALIDATION_ALERT_ID).show();
			document.getElementById(VALIDATION_ALERT_ID).focus();
		}
	};

	$(function() {

		$('#datepicker').datepicker({
	  		minDate: 1
	  	});

		resetVisualFormValidation();

		//Handle form submission
		$('#donorForm').submit(submissionHandler);

		//Full Hammer.js implementation without jQuery dependency
	  	/*
	  	var mc = new Hammer($('.removeIt')[0]);
		mc.on('panleft', removeDate);
		*/

		//Used if bringing in Hammer.js and Hammer.js jQuery plugin
		$('.removeIt').hammer().on('panleft', removeDate);

	});

})();