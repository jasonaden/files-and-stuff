/** 
 * Give page interaction.
 **/
$(function() {
  	'use strict';
  	$('#datepicker').datepicker({
  		//Only show the first of the month days
		beforeShowDay: function(date) {
			var SUNDAY = 0;
			var MONDAY = 1;
			var SATURDAY = 6;

			var dateCheck = [false, ''];
			var day = date.getDay();

			switch (date.getDate()) {
				//Check if first day of month falls during the week
				case 1:
					if (day > SUNDAY && day < SATURDAY) {
						dateCheck = [true, ''];					
					}
					break;
				//Check if second day of month is Monday (1st is Sunday)
				case 2: 
					if (day === MONDAY) {
						dateCheck = [true, ''];	
					}
					break;
				//Check if third day of month is Monday (1st day is Saturday)
				case 3:
					if (day === MONDAY) {
						dateCheck = [true, ''];	
					}				
					break;
			}
			return dateCheck;
		},
  		minDate: 1
  	});


  	//FastClick.attach(document.body);

	var removeDate = function() {
		$('#datepicker').val('');
		console.log('hello debugger');
	};
	
	//Full Hammer.js implementation without jQuery dependency
  	/*
  	var mc = new Hammer($('.removeIt')[0]);
	mc.on('panleft', removeDate);
	*/

	//Used if bringing in Hammer.js and Hammer.js jQuery plugin
	$('.removeIt').hammer().on('panleft', removeDate);

});