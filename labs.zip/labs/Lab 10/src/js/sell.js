'use strict';
/**
 * Creating ability to handle clicks and increment counter.
 **/
(function() {

	//Holds the button for product button interaction
	var largeLemonadeProductEl = $('#largeLemonadeProduct');
	var mediumLemonadeProductEl = $('#mediumLemonadeProduct');
	var healthySnackProductEl = $('#healthySnackProduct');
	var treatProductEl = $('#treatProduct');

	//Holds the button for transaction button interaction
	var transactionQuantityEl = $('#transactionQuantity');
	var transactionCostEl = $('#transactionCost');

	//Costs of the products
	var largeLemonadeCost = 3;
	var mediumLemonadeCost = 2;
	var healthySnackCost = 1;
	var treatCost = 2;

	/** 
	 * Click handler for all large lemonade clicks
	 **/
	var largeLemonadeClickHandler = function largeLemonadeClickHandler() {
		var el = largeLemonadeProductEl.find('mark');
		var count = el.text();
		el.text(Number(count) + 1);

		incrementTransactionCost(largeLemonadeCost);
		incrementTransactionQuantity();
	};

	/** 
	 * Click handler for all large lemonade clicks
	 **/
	var mediumLemonadeClickHandler = function mediumLemonadeClickHandler() {
		var el = mediumLemonadeProductEl.find('mark');
		var count = el.text();
		el.text(Number(count) + 1);

		incrementTransactionCost(mediumLemonadeCost);
		incrementTransactionQuantity();
	};	

	/** 
	 * Click handler for all large lemonade clicks
	 **/
	var healthySnackClickHandler = function healthySnackClickHandler() {
		var el = healthySnackProductEl.find('mark');
		var count = el.text();
		el.text(Number(count) + 1);

		incrementTransactionCost(healthySnackCost);
		incrementTransactionQuantity();
	};

	/** 
	 * Click handler for all large lemonade clicks
	 **/
	var treatClickHandler = function treatClickHandler() {
		var el = treatProductEl.find('mark');
		var count = el.text();
		el.text(Number(count) + 1);

		incrementTransactionCost(treatCost);
		incrementTransactionQuantity();
	};

	/** 
	 * Increments the cost of the transaction.
	 * @param cost used for incrementing
	 **/
	var incrementTransactionCost = function incrementTransactionCost(cost) {
		var el = transactionCostEl.find('mark');
		var count = el.text();
		el.text(Number(count) + cost);
	};

	/**
	 * Increments the product quantity.
	 **/
	var incrementTransactionQuantity = function incrementTransactionQuantity() {
		var el = transactionQuantityEl.find('mark');
		var count = el.text();
		el.text(Number(count) + 1);
	};

	/** 
	 * Clears out the counters.
	 **/
	var clearTransactionHandler = function clearTransactionHandler() {
		clearButtons();	
		clearTransaction();
	};

	/**
	 *	Clears all the button counters.
	 **/
	var clearButtons = function clearButtons() {
		largeLemonadeProductEl.find('mark').text(0);
		mediumLemonadeProductEl.find('mark').text(0);
		healthySnackProductEl.find('mark').text(0);
		treatProductEl.find('mark').text(0);
	};

	/**
	 *  Clears out the transaction counters.
	 **/
	var clearTransaction = function clearTransaction() {
		transactionQuantityEl.find('mark').text(0);
		transactionCostEl.find('mark').text(0);
	};

	//The initialization of this module on DOM ready
	$(function() {

		//Holds the button for clearing the transaction
		var clearTransactionButtonEl = $('#clearTransaction');

		//Event listener for product clicks
		largeLemonadeProductEl.on('click', largeLemonadeClickHandler);
		mediumLemonadeProductEl.on('click', mediumLemonadeClickHandler);
		healthySnackProductEl.on('click', healthySnackClickHandler);
		treatProductEl.on('click', treatClickHandler);

		//Event listener for clearing the transactionElement
		clearTransactionButtonEl.on('click', clearTransactionHandler);

	});
})();

