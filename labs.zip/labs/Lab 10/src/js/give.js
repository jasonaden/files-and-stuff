/** 
 * Give page interaction.
 **/
$(function() {
  	'use strict';
  	$('#datepicker').datepicker({
  		minDate: 1
  	});

  	//FastClick.attach(document.body);

	var removeDate = function() {
		$('#datepicker').val('');
		console.log('hello debugger');
	};
	
	//Full Hammer.js implementation without jQuery dependency
  	/*
  	var mc = new Hammer($('.removeIt')[0]);
	mc.on('panleft', removeDate);
	*/

	//Used if bringing in Hammer.js and Hammer.js jQuery plugin
	$('.removeIt').hammer().on('panleft', removeDate);

});