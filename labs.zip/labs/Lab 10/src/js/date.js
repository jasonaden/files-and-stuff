/**
 * Setting today's date in the header
 */
//Grabbing the element to place the date next to
var headerElement = $('header h1');
//Time element for today's date
var createdTimeElement = '';

/**
 * Calculate today's date for the HTML of the time element.
 * @param day Number of the day in the month 
 * @param month Number of the month (0 based)
 * @param fullYear Number of the 4 digit year
 * @returns today's date as a string
 **/
function calculateTodayDateHTML(day, month, fullYear) {
	//Month array :)
	var months = [ 'January', 'February', 'March', 'April', 'May', 'June', 
       	'July', 'August', 'September', 'October', 'November', 'December' ];

	//Creating today's date as a string
	return months[month] + ' ' + day + ', ' + fullYear;
}

/**
 * Calculate today's date for the dateTime attribute on the time element.
 * @param day Number of the day in the month 
 * @param month Number of the month (0 based)
 * @param fullYear Number of the 4 digit year
 * @returns today's date as a string
 **/
function calculateTodayDateAttr(day, month, fullYear) {
	var todayDay = day;
	//Taking into account the 0 based month
	var todayMonth = month + 1;

	//Add 0 for correct formatting
	if (todayDay < 10) {
		todayDay = '0' + todayDay;
	}

	//Add 0 for correct formatting
	if (todayMonth < 10) {
		todayMonth = '0' + todayMonth;
	}

	//Creating today's date as a string
	return fullYear + '-' + todayMonth + '-' + todayDay;
}

/**
 * Creates a time element with today's date in it.
 * @returns the created time element
 **/
function createTimeElement() {
	//Today's date for HTML formatting
	var todayDateHTML = '';
	//Today's date for dateTime attribute formatting
	var todayDateAttr = '';

	//Creating date object
	var date = new Date();
	//The day as a number of the month
	var day = date.getDate();
	//The month as a 0 based number
	var month = date.getMonth();
	//The full year (i.e. 4 digit year)
	var fullYear = date.getFullYear();

	//Getting the date to put in the HTML
	todayDateHTML = calculateTodayDateHTML(day, month, fullYear);
	//Getting the date to put in the attribute
	todayDateAttr = calculateTodayDateAttr(day, month, fullYear);

	//Creating a date time element
	return $('<time>', {
		html: todayDateHTML,
		dateTime: todayDateAttr
	});

}

//Remove current date time element
headerElement.next('time').remove();

//Getting a time element 
createdTimeElement = createTimeElement();

//Inserting the created element after the h1 in the header
headerElement.after(createdTimeElement);


