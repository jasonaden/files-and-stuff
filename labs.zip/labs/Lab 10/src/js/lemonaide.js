'use strict';
(function() {
	//DevelopIntelligence Namespace
	window.DI = window.DI || {};
}());


(function() {

	$('#menu').on('click', function() {
		$('header nav').toggle();
	});
})();