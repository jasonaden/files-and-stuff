/** 
 * Give page interaction.
 **/
(function() {
  	'use strict';

  	//FastClick.attach(document.body);

  	//Form elements
  	var NAME_ID = 'giverName';
  	var STREET_ADDRESS_ID = 'streetAddress';
  	var ZIPCODE_ID = 'zipcode';
  	var PHONE_ID = 'phone';
  	var EMAIL_ID = 'email';
  	var CONTACT_CHOICE_ID = 'contactChoice';
  	var DATEPICKER_ID = 'datepicker';
  	var VALIDATION_ALERT_ID = 'validationAlert';
  	var LOCAL_STORAGE_KEY = 'giveForm';

	var removeDate = function() {
		$('#datepicker').val('');
	};

	/**
	 *	Reset the warnings and alerts because of an invalid form.
	 **/
	var resetVisualFormValidation = function() {
		//Remove all errors
		$('label[for]').removeClass('error');
		//Hide validation alert
		$('#' + VALIDATION_ALERT_ID).hide();
	};

	/** 
	 *	Check form validation.
	 **/
	var isFormValid = function() {
		var isValid = true;

		resetVisualFormValidation();

		//Check Giver Street Address validation
		if (!document.getElementById(STREET_ADDRESS_ID ).validity.valid) {
			isValid = false;
			$('#' + STREET_ADDRESS_ID).prev().addClass('error');
		}

		//Check Giver Zipcode validation
		if (!document.getElementById(ZIPCODE_ID).validity.valid) {
			isValid = false;
			$('#' + ZIPCODE_ID).prev().addClass('error');					
		}

		//Check Giver Phone validation
		if (!document.getElementById(PHONE_ID).validity.valid) {
			isValid = false;
			$('#' + PHONE_ID).prev().addClass('error');		
		}

		//Check Giver Email validation
		if (!document.getElementById(EMAIL_ID).validity.valid) {
			isValid = false;
			$('#' + EMAIL_ID).prev().addClass('error');		
		}

		//Check Giver Contact Choice validation
		if (!document.getElementById(CONTACT_CHOICE_ID).validity.valid) {
			isValid = false;
			$('#' + CONTACT_CHOICE_ID).prev().addClass('error');		
		}	

		//Check Giver Datepicker validation
		if (!document.getElementById(DATEPICKER_ID).validity.valid) {
			isValid = false;
			$('#' + DATEPICKER_ID).prev().addClass('error');		
		}	

		//Check Giver Name validation
		if (!document.getElementById(NAME_ID).validity.valid) {
			isValid = false;
			$('#' + NAME_ID).prev().addClass('error');		
		}						

		return isValid;
	}

	/**
	 * Check to see if we can validate the form.
	 **/
	var submissionHandler = function(event) {
		if(isFormValid()) {
			alert('yeah valid');
			removeStoredFormData();
		} else {
			alert('not valid');
			event.preventDefault();
			//Show validation alert
			$('#' + VALIDATION_ALERT_ID).show();
			document.getElementById(VALIDATION_ALERT_ID).focus();
		}
	};

	/**
	 * Store Form Data locally.
	 **/
	var storeFormData = function() {
		var giver = {};

		giver.name = $('#' + NAME_ID).val();
		giver.phone = $('#' + PHONE_ID).val();
		giver.streetAddress = $('#' + STREET_ADDRESS_ID).val();
		giver.zipcode = $('#' + ZIPCODE_ID).val();
		giver.email = $('#' + EMAIL_ID).val();
		giver.contactChoice = $('#' + CONTACT_CHOICE_ID).val();
		giver.date = $('#' + DATEPICKER_ID).val();

		window.localStorage[LOCAL_STORAGE_KEY] = JSON.stringify(giver);

	};

	/**
	 * Retrieve Local storage data
	 **/
	var retrieveFormData = function() {
		var giverData = {};
		
		if (window.localStorage[LOCAL_STORAGE_KEY]) {
			giverData = JSON.parse(window.localStorage[LOCAL_STORAGE_KEY]);
		} else {
			giverData = undefined;
		}

		return giverData;

	};

	/**
	 * Removes Form Data from local storage.
	 **/
	var removeStoredFormData = function() {

		if (window.localStorage[LOCAL_STORAGE_KEY]) {
			window.localStorage.removeItem(LOCAL_STORAGE_KEY);
		}

	};

	/**
	 * Setup form listeners.
	 **/
	var inializeFormListeners = function() {
		//Handle form submission
		$('#donorForm').submit(submissionHandler);

		//Set up form local storage listeners
		$('label + input').on('blur', storeFormData);

		//Set up form local storage for select
		$('select').on('change', storeFormData);

		//Used if bringing in Hammer.js and Hammer.js jQuery plugin
		$('.removeIt').hammer().on('panleft', removeDate);

	};

	/**
	 * Grab data from local storage if there is any and
	 *	populate the form.
	 **/
	var inializeFormData = function() {
		var giver = retrieveFormData();

		if (giver) {
			$('#' + NAME_ID).val(giver.name);
			$('#' + PHONE_ID).val(giver.phone);
			$('#' + STREET_ADDRESS_ID).val(giver.streetAddress);
			$('#' + ZIPCODE_ID).val(giver.zipcode);
			$('#' + EMAIL_ID).val(giver.email);
			$('#' + CONTACT_CHOICE_ID).val(giver.contactChoice);
			$('#' + DATEPICKER_ID).val(giver.date);
		}

	};

	$(function() {

		$('#datepicker').datepicker({
	  		minDate: 1
	  	});

		resetVisualFormValidation();

		//Full Hammer.js implementation without jQuery dependency
	  	/*
	  	var mc = new Hammer($('.removeIt')[0]);
		mc.on('panleft', removeDate);
		*/

		inializeFormListeners();

		inializeFormData();

	});

})();