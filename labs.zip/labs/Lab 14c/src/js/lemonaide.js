'use strict';
(function() {
	//DevelopIntelligence Namespace
	window.DI = window.DI || {};
}());

(function() {

	//Have the current page reload itself
	var forceReload = function() {
		//UPDATEREADY === 4
		if (window.applicationCache.status === window.applicationCache.UPDATEREADY) {
			window.location.reload(true);
		}
	};

	(function() {
		$(window.applicationCache).on('updateready', forceReload);
	})();
	
})();
