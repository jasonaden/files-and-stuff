'use strict';

module.exports = function(grunt) {

  // Load grunt tasks automatically
  require('load-grunt-tasks')(grunt);

  // Time how long tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  // Project configuration.
  grunt.initConfig({

    // Transpile our less code
    less: {
      home: {
        expand: true,
        src: 'src/css/pages/home.less',
        ext: '.css'        
      },
      give: {
        expand: true,
        src: 'src/css/pages/give.less',
        ext: '.css'         
      },
      sell: {
        expand: true,
        src: 'src/css/pages/sell.less',
        ext: '.css'         
      }      
    },

    //Live watching
    watch: {
      scripts: {
        files: [
          'src/**/*.html',
          'src/**/*.js',
          'src/css/components/**/*.less',
          'src/css/pages/**/*.less'
        ],
        tasks: ['less'],
        options: {
          livereload: true
        }
      }
    }

  });

};